import os
import serpapi

SERP_API_KEY = os.getenv("SerpAPI")

def basic_web_search(query, num_results=5):
    params = {
        "q": query,
        "engine": "google",
        "hl": "en",
        "gl": "in",
        "num": num_results,
        "api_key": SERP_API_KEY
    }

    search = serpapi.search(params)
    response = search.as_dict()

    results = []
    for r in response.get("organic_results", []):
        results.append({
            "title": r.get("title"),
            "url": r.get("link"),
            "snippet": r.get("snippet")
        })

    return {
        "query": query,
        "results": results,
        "query_type": "basic_web_search"
    }

def lambda_handler(event, context):
    queries = event.get("queries", [])
    all_results = {}

    for q in queries:
        all_results[q] = basic_web_search(q)

    return all_results
